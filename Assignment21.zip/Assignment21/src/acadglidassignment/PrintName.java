package acadglidassignment;

public class PrintName {
	public static void main(String[] args) {
		if (System.out.printf("NIKHIL SHARMA") != null) {
		}
	}

}
